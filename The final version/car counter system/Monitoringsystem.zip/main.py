
from machine import Pin
from time import sleep

entrance = Pin(34,Pin.IN)
exit = Pin(35,Pin.IN)
leds = [21, 18, 5, 17, 16, 4, 13, 2]
led_list = [ Pin(x , Pin.OUT) for x in leds]
counter = 0
entrance_last_state = 0 
exit_last_state = 0
#_____________________________#
while True:
    entrance_current = entrance.value()
    exit_current = exit.value()

    if entrance_current == 1 and entrance_last_state == 0:
        sleep(30 / 1000)
        if entrance.value() == 1:
            if counter < 8:
                led_list[counter].on()
                counter += 1
            else:
                print("❌ There is no place for another car")
    entrance_last_state = entrance_current
    
    if exit_last_state == 0 and exit_current == 1 :
        sleep(30/1000)
        if exit.value() == 1 :
            if counter > 0 :
                led_list[counter-1].off()
                counter -= 1
            else:
                print("❌ The garage is empty")
    exit_last_state = exit_current

    sleep(0.01)